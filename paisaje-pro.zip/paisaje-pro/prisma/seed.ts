import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../src/generated/prisma/client";

const adapter = new PrismaPg({ connectionString: process.env.DATABASE_URL! });
const prisma = new PrismaClient({ adapter });

function date(year: number, month: number, day: number) {
  return new Date(Date.UTC(year, month, day));
}

async function main() {
  const now = new Date();
  const year = now.getUTCFullYear();
  const month = now.getUTCMonth();
  const currentDay = now.getUTCDate();

  await prisma.payment.deleteMany();
  await prisma.visit.deleteMany();
  await prisma.client.deleteMany();
  await prisma.businessSettings.upsert({
    where: { id: "main" },
    update: { businessName: "Verde Claro Landscaping", ownerName: "Alex Rivera", phone: "(555) 010-2040", email: "hola@verdeclaro.example", address: "1250 Garden Ave, Orlando, FL", defaultVisitsPerMonth: 2 },
    create: { id: "main", businessName: "Verde Claro Landscaping", ownerName: "Alex Rivera", phone: "(555) 010-2040", email: "hola@verdeclaro.example", address: "1250 Garden Ave, Orlando, FL", defaultVisitsPerMonth: 2 },
  });

  const examples = [
    { name: "Ana Martínez (Ejemplo)", phone: "(555) 014-1280", address: "742 Palm Street, Orlando, FL", notes: "Prefiere servicio por la mañana. Portón lateral.", servicePrice: 85, paymentDay: 15 },
    { name: "Carlos Vega (Ejemplo)", phone: "(555) 018-4472", address: "118 Lakeview Drive, Winter Park, FL", notes: "Incluir recorte de setos cada segunda visita.", servicePrice: 110, paymentDay: 20 },
    { name: "Lucía Torres (Ejemplo)", phone: "(555) 013-9061", address: "905 Magnolia Lane, Orlando, FL", notes: "Avisar por mensaje antes de llegar.", servicePrice: 75, paymentDay: 10 },
    { name: "Roberto Díaz (Ejemplo)", phone: "(555) 016-3328", address: "311 Cypress Court, Maitland, FL", notes: "No usar sopladora cerca del patio trasero.", servicePrice: 95, paymentDay: 25 },
    { name: "Elena Cruz (Ejemplo)", phone: "(555) 011-7745", address: "62 Orange Blossom Rd, Orlando, FL", notes: "Cliente de demostración, servicio frontal y trasero.", servicePrice: 120, paymentDay: 18 },
  ];

  for (let index = 0; index < examples.length; index++) {
    const item = examples[index];
    const client = await prisma.client.create({ data: item });
    const firstDay = Math.max(1, Math.min(currentDay - 3 + index, 12));
    const secondDay = Math.min(26, Math.max(currentDay + 3 + index * 2, 15));
    const firstCompleted = index < 3;
    await prisma.visit.createMany({ data: [
      { clientId: client.id, scheduledDate: date(year, month, firstDay), completed: firstCompleted, actualDate: firstCompleted ? date(year, month, firstDay) : null, notes: firstCompleted ? "Servicio de demostración completado." : "" },
      { clientId: client.id, scheduledDate: date(year, month, secondDay), completed: false },
    ] });
    const paid = index === 0 || index === 2;
    const dueDay = Math.min(item.paymentDay, new Date(Date.UTC(year, month + 1, 0)).getUTCDate());
    await prisma.payment.create({ data: { clientId: client.id, amount: item.servicePrice * 2, dueDate: date(year, month, dueDay), status: paid ? "PAID" : "PENDING", paymentDate: paid ? date(year, month, Math.max(1, dueDay - 2)) : null, notes: "Registro mensual de demostración." } });
  }
}

main().then(() => prisma.$disconnect()).catch(async (error) => { console.error(error); await prisma.$disconnect(); process.exit(1); });
