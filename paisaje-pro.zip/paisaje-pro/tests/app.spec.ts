import { expect, test } from "@playwright/test";

test("carga las áreas principales sin errores de consola", async ({ page }, testInfo) => {
  const errors: string[] = [];
  page.on("console", (message) => { if (message.type() === "error") errors.push(message.text()); });
  page.on("pageerror", (error) => errors.push(error.message));

  const pages = [
    ["/", "Resumen del negocio"],
    ["/clientes", "Clientes"],
    ["/calendario", "Calendario de servicios"],
    ["/pagos", "Pagos"],
    ["/configuracion", "Configuración"],
  ];
  for (const [path, heading] of pages) {
    await page.goto(path);
    await expect(page.getByRole("heading", { name: heading, exact: true })).toBeVisible();
    await expect(page.getByText("Cargando información...")).toBeHidden({ timeout: 10_000 });
  }
  expect(errors).toEqual([]);
  await page.screenshot({ path: `test-results/${testInfo.project.name}-configuracion.png`, fullPage: true });
});

test("muestra métricas, ejemplos y filtros operativos", async ({ page }, testInfo) => {
  const errors: string[] = [];
  page.on("console", (message) => { if (message.type() === "error") errors.push(message.text()); });
  await page.goto("/");
  await expect(page.getByText("Clientes activos")).toBeVisible();
  await expect(page.getByText("Cobrado", { exact: true })).toBeVisible();
  await page.screenshot({ path: `test-results/${testInfo.project.name}-inicio.png`, fullPage: true });
  await page.goto("/clientes");
  await expect(page.getByText("Ana Martínez (Ejemplo)")).toBeVisible();
  await page.getByRole("button", { name: "Nuevo cliente" }).click();
  await page.getByRole("button", { name: "Guardar cliente" }).click();
  await expect(page.locator('input[name="name"]')).toHaveJSProperty("validity.valid", false);
  expect(errors).toEqual([]);
});
