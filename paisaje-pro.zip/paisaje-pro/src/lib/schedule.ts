import { prisma } from "@/lib/prisma";
import { monthRange } from "@/lib/dates";

export async function ensureMonthlyVisits(month?: string) {
  const range = monthRange(month);
  const [clients, settings, counts] = await Promise.all([
    prisma.client.findMany({ where: { active: true }, select: { id: true, paymentDay: true } }),
    prisma.businessSettings.upsert({ where: { id: "main" }, update: {}, create: { id: "main" } }),
    prisma.visit.groupBy({ by: ["clientId"], where: { scheduledDate: { gte: range.start, lt: range.end } }, _count: true }),
  ]);
  const current = new Map(counts.map((item) => [item.clientId, item._count]));
  const [year, monthNumber] = range.month.split("-").map(Number);
  const daysInMonth = new Date(Date.UTC(year, monthNumber, 0)).getUTCDate();
  const creates = [];
  for (const client of clients) {
    const missing = Math.max(0, settings.defaultVisitsPerMonth - (current.get(client.id) ?? 0));
    for (let index = 0; index < missing; index++) {
      const day = Math.min(daysInMonth, 7 + ((current.get(client.id) ?? 0) + index) * 14);
      creates.push({ clientId: client.id, scheduledDate: new Date(Date.UTC(year, monthNumber - 1, day)) });
    }
  }
  if (creates.length) await prisma.visit.createMany({ data: creates });
  return range;
}
