"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { CalendarDays, CreditCard, LayoutDashboard, Leaf, Settings, Users } from "lucide-react";

const links = [
  { href: "/", label: "Inicio", mobileLabel: "Inicio", icon: LayoutDashboard },
  { href: "/clientes", label: "Clientes", mobileLabel: "Clientes", icon: Users },
  { href: "/calendario", label: "Calendario", mobileLabel: "Agenda", icon: CalendarDays },
  { href: "/pagos", label: "Pagos", mobileLabel: "Pagos", icon: CreditCard },
  { href: "/configuracion", label: "Configuración", mobileLabel: "Ajustes", icon: Settings },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  return (
    <div className="min-h-screen bg-[var(--canvas)] text-[var(--ink)]">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 border-r border-[var(--line)] bg-white lg:flex lg:flex-col">
        <div className="flex h-20 items-center gap-3 border-b border-[var(--line)] px-6">
          <span className="grid size-10 place-items-center rounded-md bg-[var(--forest)] text-white"><Leaf size={21} /></span>
          <div><p className="font-semibold leading-tight">Paisaje Pro</p><p className="text-xs text-[var(--muted)]">Gestión del negocio</p></div>
        </div>
        <nav className="flex-1 space-y-1 p-3">
          {links.map(({ href, label, icon: Icon }) => {
            const active = href === "/" ? pathname === href : pathname.startsWith(href);
            return <Link key={href} href={href} className={`flex h-11 items-center gap-3 rounded-md px-3 text-sm font-medium transition ${active ? "bg-[var(--forest-soft)] text-[var(--forest)]" : "text-[var(--muted)] hover:bg-gray-50 hover:text-[var(--ink)]"}`}><Icon size={18} />{label}</Link>;
          })}
        </nav>
        <div className="m-4 rounded-md border border-amber-200 bg-amber-50 p-3 text-xs leading-relaxed text-amber-900">Modo demostración<br /><span className="text-amber-700">Los registros incluidos son ficticios.</span></div>
      </aside>
      <header className="sticky top-0 z-20 border-b border-[var(--line)] bg-white/95 px-4 backdrop-blur lg:hidden">
        <div className="flex h-14 items-center gap-2 font-semibold"><Leaf size={20} className="text-[var(--forest)]" />Paisaje Pro</div>
        <nav className="grid grid-cols-5 gap-1 pb-2">
          {links.map(({ href, mobileLabel, icon: Icon }) => {
            const active = href === "/" ? pathname === href : pathname.startsWith(href);
            return <Link key={href} href={href} className={`flex min-w-0 flex-col items-center gap-1 rounded-md px-1 py-2 text-[10px] font-medium ${active ? "bg-[var(--forest)] text-white" : "bg-gray-100 text-[var(--muted)]"}`}><Icon size={15} /><span className="truncate">{mobileLabel}</span></Link>;
          })}
        </nav>
      </header>
      <main className="lg:pl-60"><div className="mx-auto max-w-[1440px] p-4 sm:p-6 lg:p-8">{children}</div></main>
    </div>
  );
}
