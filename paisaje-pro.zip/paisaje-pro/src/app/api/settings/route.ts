import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { badRequest, toNumber } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json(await prisma.businessSettings.upsert({ where: { id: "main" }, update: {}, create: { id: "main" } }));
}

export async function PUT(request: NextRequest) {
  const body = await request.json();
  const visits = toNumber(body.defaultVisitsPerMonth);
  if (!body.businessName?.trim()) return badRequest("El nombre del negocio es obligatorio.");
  if (!Number.isInteger(visits) || visits < 1 || visits > 8) return badRequest("Las visitas mensuales deben estar entre 1 y 8.");
  const settings = await prisma.businessSettings.upsert({ where: { id: "main" }, create: { id: "main", businessName: body.businessName.trim(), ownerName: body.ownerName?.trim() ?? "", phone: body.phone?.trim() ?? "", email: body.email?.trim() ?? "", address: body.address?.trim() ?? "", defaultVisitsPerMonth: visits }, update: { businessName: body.businessName.trim(), ownerName: body.ownerName?.trim() ?? "", phone: body.phone?.trim() ?? "", email: body.email?.trim() ?? "", address: body.address?.trim() ?? "", defaultVisitsPerMonth: visits } });
  return NextResponse.json(settings);
}
